package main

import (
	"csa"
)

func main() {
	csa.Start()
}
